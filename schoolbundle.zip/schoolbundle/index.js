$(function(){
    $('body').click(()=>{

    })
})
